# 🚀 Panduan Deploy ke Vercel

Dokumen ini menjelaskan langkah-langkah deploy **Vilkar Kosambi Blok D** ke Vercel.
Versi ini sudah dikonfigurasi khusus untuk environment Vercel (PostgreSQL + Vercel Blob).

---

## 0. Apa yang Berubah dari Versi Sandbox?

| Aspek | Sandbox (lama) | Vercel (baru) |
|---|---|---|
| Database | SQLite file `db/custom.db` | PostgreSQL (Neon / Vercel Postgres) |
| Upload berkas | Filesystem `/public/uploads/` | **Vercel Blob** (object storage) |
| Session log | File JSON `session-log.json` | Tabel `SessionLog` di PostgreSQL |
| Auth secret | Fallback hardcoded | Wajib set `AUTH_SECRET` env var |
| `/api/reset-data` | Tanpa auth (bug!) | Wajib superadmin |
| Build script | `next build && cp -r ...` | `prisma generate && next build` |
| `output: "standalone"` | Ya | Dihapus (tidak perlu) |

---

## 1. Persiapan Akun & Tools

1. **Akun Vercel** — gratis di https://vercel.com/signup
2. **Akun Neon** (untuk PostgreSQL gratis) — https://neon.tech
   - Alternatif: Vercel Postgres, Supabase, PlanetScale
3. **Vercel CLI** (opsional, tapi mempermudah):
   ```bash
   npm install -g vercel
   ```

---

## 2. Setup Database PostgreSQL di Neon

1. Buka https://neon.tech → Sign up → New Project
2. Isi:
   - **Name**: `vilkar-kosambi`
   - **Region**: Singapore (`ap-southeast-1`) — paling dekat ke Indonesia
   - **Postgres version**: 17 (latest)
3. Setelah project dibuat, klik **"Connect"** → copy 2 connection strings:
   - **Pooled connection** (untuk app runtime — pakai PgBouncer):
     ```
     postgresql://user:pass@ep-xxx.ap-southeast-1.aws.neon.tech/vilkar?sslmode=require&pgbouncer=true
     ```
   - **Direct connection** (untuk Prisma migrate/push):
     ```
     postgresql://user:pass@ep-xxx.ap-southeast-1.aws.neon.tech/vilkar?sslmode=require
     ```
4. Simpan kedua string ini — nanti dipakai di step 5.

---

## 3. Push Project ke Git

1. Buat repo di GitHub (private direkomendasikan karena ada kode aplikasi).
2. Push isi folder ini ke repo:
   ```bash
   cd vilkar-kosambi-blok-d
   git init
   git add .
   git commit -m "Initial commit - Vercel-ready"
   git branch -M main
   git remote add origin https://github.com/USERNAME/vilkar-kosambi.git
   git push -u origin main
   ```

> File `.env`, `.env.local`, `*.db`, `session-log.json`, `/public/uploads/` sudah otomatis
> di-ignore oleh `.gitignore`. Jangan pernah commit secret.

---

## 4. Import Project ke Vercel

1. Buka https://vercel.com/new
2. Pilih **Import Git Repository** → pilih repo `vilkar-kosambi`
3. Konfigurasi:
   - **Framework Preset**: Next.js (auto-detected)
   - **Build Command**: `bun run build` (sudah dari `vercel.json`)
   - **Install Command**: `bun install` (sudah dari `vercel.json`)
   - **Root Directory**: `./` (default)
4. **JANGAN klik Deploy dulu** — klik dulu **"Environment Variables"** dan isi semua (lihat step 5).

---

## 5. Set Environment Variables di Vercel

Masuk ke **Vercel Project → Settings → Environment Variables**, tambahkan:

| Key | Value | Environment |
|---|---|---|
| `DATABASE_URL` | Pooled connection string Neon | Production, Preview, Development |
| `DIRECT_URL` | Direct connection string Neon | Production, Preview, Development |
| `AUTH_SECRET` | Random 64-char hex (lihat bawah) | Production, Preview, Development |

Cara generate `AUTH_SECRET`:

```bash
# Jalankan di terminal lokal:
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
# Atau:
openssl rand -hex 32
```

Copy outputnya (64 char hex) → paste ke Vercel env var `AUTH_SECRET`.

---

## 6. Setup Vercel Blob Storage (untuk upload berkas)

1. Di Vercel project, buka **Storage** tab → **Create new** → pilih **Blob Store**
2. Beri nama `vilkar-blob`, pilih region `Singapore (sin1)`
3. Klik **Connect to project** → Pilih project `vilkar-kosambi`
4. Vercel otomatis menambahkan env var `BLOB_READ_WRITE_TOKEN` ke project
   - Token ini otomatis tersync, Anda tidak perlu set manual

> Vercel Blob free tier: 1 GB storage + 10 GB bandwidth/bulan (cukup untuk RT).

---

## 7. Deploy & Migrate Database

1. Klik **Deploy** di Vercel — tunggu build selesai (1-3 menit).
2. Build akan jalan `prisma generate` dulu, lalu `next build`.
3. **PENTING**: Skema DB belum di-push! Setup DB dengan cara berikut.

### Setup skema DB (jalankan sekali):

**Opsi A — via Vercel CLI (paling gampang)**:

```bash
# Install Vercel CLI lokal
npm install -g vercel

# Login & link project
cd vilkar-kosambi-blok-d
vercel login
vercel link   # pilih project yang sudah di-deploy

# Pull env vars dari Vercel ke .env.local
vercel env pull .env.local

# Sekarang prisma bisa pakai DATABASE_URL & DIRECT_URL
npx prisma db push --accept-data-loss

# (Opsional) Muat data contoh untuk testing:
# Login sebagai superadmin lewat UI → klik tombol "Data Contoh"
```

**Opsi B — manual via Neon console**:
- Buka Neon console → SQL Editor
- Jalankan SQL hasil dari `npx prisma migrate diff` (lebih rumit, tidak direkomendasikan)

---

## 8. Buat Akun Superadmin Pertama

Karena DB baru kosong, tidak ada akun admin. Lakukan salah satu:

### Opsi A: Auto-create default (tercepat)

```bash
# Trigger endpoint /api/auth/reset (public, hanya recreate kalau belum ada)
curl -X POST https://NAMA-PROJECT.vercel.app/api/auth/reset
```

Response: `{"success":true,"message":"Akun default admin & superadmin telah dibuat ulang..."}`

Default username: `superadmin` / `super123` dan `admin` / `admin123`.

> ⚠️ **Wajib ganti password default** setelah login pertama! Klik **Kelola Login** → ganti password.

### Opsi B: Push via Prisma Studio

```bash
vercel env pull .env.local
npx prisma studio
# Buka tabel AdminUser → New Record → isi username/password (hash), role, nama
```

Password harus di-hash pakai scrypt. Lihat `src/lib/auth.ts` function `hashPassword`.

---

## 9. Verifikasi Deploy

1. Buka URL Vercel (mis: `https://vilkar-kosambi.vercel.app`)
2. Login sebagai superadmin
3. Klik **"Data Contoh"** → muat 6 warga + transaksi + tagihan contoh
4. Test upload berkas (gambar KTP) → cek di tab Berkas
5. Test download berkas → file harusnya terdownload
6. Cek tab **Pengguna Login** → harusnya ada record session baru
7. Buka **Vercel dashboard → Storage → Blob** → harusnya ada file di folder `berkas/`

---

## 10. Custom Domain (Opsional)

1. Vercel Project → Settings → Domains → Add
2. Masukkan domain (mis: `kas.vilkar-kosambi-blok-d.id`)
3. Update DNS record di registrar Anda (CNAME → `cname.vercel-dns.com`)
4. Tunggu propagation (5-30 menit)

---

## 11. Monitor & Troubleshooting

### Lihat log
- Vercel dashboard → Project → **Logs** / **Functions** → filter by route

### Common issues

| Masalah | Solusi |
|---|---|
| `AUTH_SECRET env var wajib diset` | Set env var `AUTH_SECRET` di Vercel (step 5) |
| `BLOB_READ_WRITE_TOKEN belum diset` | Hubungkan Blob store ke project (step 6) |
| `Prisma: database connection error` | Cek `DATABASE_URL` — pastikan pakai Pooled connection dengan `?pgbouncer=true` |
| `Can't reach database server` | Cek region database = region Vercel function |
| Upload gagal > 4.5MB | Vercel free plan limit body size 4.5MB. Untuk file > 4.5MB, pakai client-side upload ke Vercel Blob (lihat `@vercel/blob/client`'s `upload()`) |
| Cold start lambat | Prisma client di-generate on postinstall. Pertimbangkan `@prisma/edge` kalau perlu |

---

## 12. Upgrade ke Production-Grade (Opsional)

Hal yang perlu ditambahkan sebelum go-live untuk RT sesungguhnya:

1. **Tambah rate limiting** di `/api/auth/login` (sekarang tidak ada — rentan brute force). Pakai `@upstash/ratelimit` + Vercel KV.
2. **Tambah auth di GET endpoint** yang sekarang publik:
   - `/api/berkas`, `/api/berkas/download/[id]` (wajib admin — file sensitif)
   - `/api/warga/export`, `/api/warga/template` (wajib admin — NIK bocor)
   - `/api/dashboard` (boleh publik untuk ringkasan, atau filter)
3. **CSRF protection** untuk write operations
4. **Password policy** minimal 8 char + kombinasi huruf/angka
5. **Backup otomatis** Neon → nightly snapshot ke S3/R2
6. **Analytics** — Vercel Analytics atau Plausible

---

## 📁 Struktur Project Vercel-ready

```
vilkar-kosambi-blok-d/
├── prisma/
│   └── schema.prisma           # PostgreSQL + SessionLog model
├── public/                      # Static assets (favicon, icons PWA)
├── src/
│   ├── app/
│   │   ├── api/                 # API routes (serverless functions)
│   │   │   ├── berkas/          # ✅ Pakai @vercel/blob
│   │   │   ├── reset-data/      # ✅ Sekarang butuh auth superadmin
│   │   │   └── ...
│   │   ├── layout.tsx
│   │   └── page.tsx
│   ├── components/
│   ├── hooks/
│   └── lib/
│       ├── auth.ts              # ✅ AUTH_SECRET wajib, no fallback
│       ├── db.ts                # Prisma client singleton
│       ├── session-log.ts      # ✅ Pakai DB Prisma, bukan file JSON
│       └── ...
├── .env.example                 # Template env vars
├── .gitignore                   # ✅ Updated untuk Vercel
├── next.config.ts               # ✅ Tanpa output: "standalone"
├── package.json                 # ✅ @vercel/blob added, build simplified
├── vercel.json                  # ✅ Vercel config (Bun + region)
└── VERCEL-DEPLOY.md             # File ini
```

---

## ❓ FAQ

**Q: Bisakah pakai SQLite di Vercel?**
A: Tidak. Vercel punya filesystem read-only & ephemeral. SQLite file-based tidak akan persist.
   Wajib pakai DB eksternal (Neon Postgres direkomendasikan).

**Q: Bisakah pakai file upload ke `/public/uploads/` di Vercel?**
A: Tidak. `/public` read-only di Vercel. Pakai Vercel Blob (atau Cloudinary/S3/UploadThing).

**Q: Bisakah pakai WebSocket di Vercel?**
A: Tidak原生. Vercel serverless tidak support persistent WebSocket.
   Kalau butuh realtime, pakai Vercel KV pub/sub, Pusher, atau Ably.

**Q: Berapa biaya bulanan?**
A: Untuk RT (pemakaian kecil): **$0**.
   - Vercel Hobby: free (100GB bandwidth, 100GB-hours compute)
   - Neon Free: 0.5 GB storage, cukup untuk 1 RT
   - Vercel Blob Free: 1 GB storage, 10GB bandwidth
   - Domain: ~$10-15/tahun (opsional)

---

## ✅ Checklist Deploy

- [ ] Akun Vercel dibuat
- [ ] Akun Neon dibuat, project `vilkar-kosambi` di-create
- [ ] Pooled + Direct connection string disalin
- [ ] Repo GitHub dibuat, code sudah di-push
- [ ] Project di-import ke Vercel
- [ ] Env vars di-set: `DATABASE_URL`, `DIRECT_URL`, `AUTH_SECRET`
- [ ] Blob store di-create & di-attach ke project
- [ ] Klik Deploy, build sukses
- [ ] `npx prisma db push` dijalankan (via Vercel CLI pull env)
- [ ] Akun superadmin dibuat (via `/api/auth/reset`)
- [ ] Password default diganti
- [ ] Data contoh di-load (untuk test)
- [ ] Upload + download berkas berfungsi
- [ ] Custom domain (opsional)

---

Selamat! Aplikasi Vilkar Kosambi Blok D sudah live di Vercel. 🎉
