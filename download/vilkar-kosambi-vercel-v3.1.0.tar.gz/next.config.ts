import type { NextConfig } from "next";

// Konfigurasi untuk Vercel — output: "standalone" tidak diperlukan
// karena Vercel sudah handle build & deploy Next.js natively.
const nextConfig: NextConfig = {
  /* config options here */
  typescript: {
    // Tetap ignore build errors untuk kompatibilitas (boleh dinyalakan
    // ke `false` setelah type-check seluruh codebase bersih).
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
};

export default nextConfig;
