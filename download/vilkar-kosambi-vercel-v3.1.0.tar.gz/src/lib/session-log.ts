// Audit trail login — disimpan di tabel SessionLog (Prisma + PostgreSQL)
// Menggantikan implementasi lama yang pakai file JSON (filesystem tidak persisten di Vercel)

import { db } from "@/lib/db";

const SESSION_MAX_AGE = 1000 * 60 * 60 * 24 * 7; // 7 hari

export interface SessionRecord {
  id: string; // session id (dari token)
  role: string;
  loginAt: string; // ISO
  logoutAt: string | null;
  ipAddress: string;
  userAgent: string;
}

function toRecord(row: {
  sessionId: string;
  role: string;
  loginAt: Date;
  logoutAt: Date | null;
  ipAddress: string;
  userAgent: string;
}): SessionRecord {
  return {
    id: row.sessionId,
    role: row.role,
    loginAt: row.loginAt.toISOString(),
    logoutAt: row.logoutAt ? row.logoutAt.toISOString() : null,
    ipAddress: row.ipAddress,
    userAgent: row.userAgent,
  };
}

// Catat login baru
export async function recordLogin(
  sessionId: string,
  role: string,
  req: Request
): Promise<void> {
  const ip =
    req.headers.get("x-forwarded-for") ||
    req.headers.get("x-real-ip") ||
    "unknown";
  const ua = req.headers.get("user-agent") || "unknown";

  // Upsert supaya kalau sessionId sudah ada (jarang), tetap konsisten
  await db.sessionLog.upsert({
    where: { sessionId },
    create: {
      sessionId,
      role,
      ipAddress: ip,
      userAgent: ua,
    },
    update: {
      role,
      ipAddress: ip,
      userAgent: ua,
      loginAt: new Date(),
      logoutAt: null,
    },
  });
}

// Catat logout (mark session as logged out)
export async function recordLogout(sessionId: string): Promise<void> {
  await db.sessionLog.updateMany({
    where: { sessionId, logoutAt: null },
    data: { logoutAt: new Date() },
  });
}

// Ambil semua session (raw) - untuk superadmin
export async function getAllSessions(): Promise<SessionRecord[]> {
  const rows = await db.sessionLog.findMany({
    orderBy: { loginAt: "desc" },
    take: 200, // batasi 200 record terbaru
  });
  return rows.map(toRecord);
}

// Ambil session aktif (belum logout & belum expired)
export async function getActiveSessions(): Promise<SessionRecord[]> {
  const cutoff = new Date(Date.now() - SESSION_MAX_AGE);
  const rows = await db.sessionLog.findMany({
    where: {
      logoutAt: null,
      loginAt: { gt: cutoff },
    },
    orderBy: { loginAt: "desc" },
    take: 200,
  });
  return rows.map(toRecord);
}

// Revoke session (force logout) - superadmin only
export async function revokeSession(sessionId: string): Promise<void> {
  await db.sessionLog.updateMany({
    where: { sessionId, logoutAt: null },
    data: { logoutAt: new Date() },
  });
}

// Hapus semua session log (dipanggil dari /api/reset-data)
export async function clearAllSessions(): Promise<void> {
  await db.sessionLog.deleteMany({});
}
