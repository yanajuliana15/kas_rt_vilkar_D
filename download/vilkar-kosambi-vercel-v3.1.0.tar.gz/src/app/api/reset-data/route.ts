import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { ensureDefaultUsers, getRole } from "@/lib/auth";
import { clearAllSessions } from "@/lib/session-log";

// POST /api/reset-data - hapus SEMUA data kecuali akun superadmin
// HANYA superadmin yang boleh memanggil endpoint ini.
// Sebelumnya TANPA auth check (bug kritis) — sekarang diproteksi.
export async function POST(req: NextRequest) {
  try {
    // 1. Wajib superadmin
    const role = await getRole(req);
    if (role !== "superadmin") {
      return NextResponse.json(
        { error: "Akses ditolak. Hanya superadmin yang bisa reset data." },
        { status: 403 }
      );
    }

    // 2. Hapus semua data transaksional (urutan penting karena relasi)
    await db.pembayaranPinjaman.deleteMany();
    await db.peminjaman.deleteMany();
    await db.tagihan.deleteMany();
    await db.berkas.deleteMany();
    await db.dokumentasi.deleteMany();
    await db.kasTransaction.deleteMany();
    await db.struktur.deleteMany();
    await db.warga.deleteMany();

    // 3. Bersihkan audit log sesi
    await clearAllSessions();

    // 4. Hapus SEMUA AdminUser KECUALI superadmin
    await db.adminUser.deleteMany({
      where: { role: { not: "superadmin" } },
    });

    // 5. Pastikan minimal ada 1 superadmin
    await ensureDefaultUsers();

    // 6. Reset settings (iuran amount, dll) - keep adminPassword/superadminPassword
    await db.setting.deleteMany({
      where: { key: { notIn: ["adminPassword", "superadminPassword"] } },
    });

    return NextResponse.json({
      success: true,
      message:
        "Semua data dihapus. Hanya akun superadmin yang tersisa.",
    });
  } catch (e) {
    return NextResponse.json(
      { error: "Gagal reset data", detail: String(e) },
      { status: 500 }
    );
  }
}
