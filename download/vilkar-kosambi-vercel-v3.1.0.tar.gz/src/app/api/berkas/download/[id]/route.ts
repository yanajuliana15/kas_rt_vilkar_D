import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";

// GET /api/berkas/download/[id] - proxy download dari Vercel Blob
// (Kita proxy supaya bisa tambah auth check di masa depan & URL tidak bocor ke publik)
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const berkas = await db.berkas.findUnique({ where: { id } });
    if (!berkas)
      return NextResponse.json({ error: "Berkas tidak ditemukan" }, { status: 404 });

    // filePath sekarang berisi URL Vercel Blob
    const blobUrl = berkas.filePath;
    if (!blobUrl.startsWith("http")) {
      return NextResponse.json(
        { error: "Path berkas tidak valid (bukan blob URL)" },
        { status: 500 }
      );
    }

    // Fetch dari Vercel Blob dan stream ke client
    const upstream = await fetch(blobUrl);
    if (!upstream.ok) {
      return NextResponse.json(
        { error: "Gagal mengunduh berkas dari storage", status: upstream.status },
        { status: 502 }
      );
    }

    const headers = new Headers();
    headers.set(
      "Content-Type",
      berkas.fileType || upstream.headers.get("content-type") || "application/octet-stream"
    );
    headers.set(
      "Content-Disposition",
      `attachment; filename="${encodeURIComponent(berkas.namaBerkas)}"`
    );
    const contentLength =
      upstream.headers.get("content-length") || String(berkas.fileSize);
    headers.set("Content-Length", contentLength);

    return new NextResponse(upstream.body, {
      status: 200,
      headers,
    });
  } catch (e) {
    return NextResponse.json(
      { error: "Gagal mengunduh berkas", detail: String(e) },
      { status: 500 }
    );
  }
}
