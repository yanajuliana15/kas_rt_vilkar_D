import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { del } from "@vercel/blob";
import { getRole } from "@/lib/auth";

// DELETE /api/berkas/[id]
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const role = await getRole(req);
    if (role === "warga") {
      return NextResponse.json({ error: "Akses ditolak. Login sebagai admin." }, { status: 403 });
    }
    const { id } = await params;
    const berkas = await db.berkas.findUnique({ where: { id } });
    if (!berkas)
      return NextResponse.json({ error: "Berkas tidak ditemukan" }, { status: 404 });

    // Hapus file dari Vercel Blob (filePath = blob URL)
    if (berkas.filePath.startsWith("http")) {
      try {
        await del(berkas.filePath);
      } catch {
        // ignore kalau blob sudah tidak ada
      }
    }

    await db.berkas.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (e) {
    return NextResponse.json(
      { error: "Gagal menghapus berkas", detail: String(e) },
      { status: 500 }
    );
  }
}
