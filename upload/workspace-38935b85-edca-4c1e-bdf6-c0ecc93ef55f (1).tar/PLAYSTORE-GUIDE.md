# Panduan Publish ke Google Play Store

Aplikasi **Vilkar Kosambi Blok D** sudah PWA-ready (manifest.json, service worker, icon 512x512). Untuk publish ke Play Store, gunakan **TWA (Trusted Web Activity)** — bungkus PWA jadi app Android native.

## Prasyarat

1. ✅ Aplikasi sudah PWA (sudah ada: manifest.json, sw.js, icon-512.png)
2. ❌ **Deploy ke hosting HTTPS** (Play Store butuh URL publik)
3. ❌ **Akun Google Play Console** ($25 one-time, bayar sekali seumur hidup)

---

## Langkah 1: Deploy ke Hosting HTTPS

Pilih salah satu (gratis):

### Opsi A: Vercel (paling mudah, rekomendasi)
```bash
# Install Vercel CLI
npm i -g vercel

# Di folder project
vercel

# Ikuti prompt, deploy ke URL seperti: https://kas-vilkar.vercel.app
```

### Opsi B: Netlify
```bash
# Build dulu
npm run build

# Drag folder .next/standalone ke https://app.netlify.com/drop
```

### Opsi C: Cloudflare Pages
- Push code ke GitHub
- Connect ke Cloudflare Pages
- Auto-deploy

**Catatan**: Setelah deploy, pastikan URL bisa diakses publik & HTTPS aktif.

---

## Langkah 2: Generate Android App (TWA)

### Opsi A: PWABuilder (paling mudah, no coding)

1. Buka **https://www.pwabuilder.com**
2. Masukkan URL deploy Anda (mis: `https://kas-vilkar.vercel.app`)
3. Klik **Start**
4. Tunggu analisa selesai (pastikan score tinggi)
5. Klik **Package For Stores** → pilih **Android**
6. Isi form:
   - **Package ID**: `com.vilkar.kas` (format reverse domain)
   - **App name**: `Kas Vilkar Kosambi`
   - **Launcher name**: `Kas Vilkar`
   - **Version**: `1.0.0`
   - **Signing key**: Generate baru atau upload existing
7. Klik **Generate** → download **`.aab` file** + **keystore (.jks)**

### Opsi B: Bubblewrap CLI (lebih kontrol)

```bash
# Install Bubblewrap
npm i -g @bubblewrap/cli

# Inisialisasi dari manifest
bubblewrap init --manifest https://kas-vilkar.vercel.app/manifest.json

# Build Android App Bundle
bubblewrap build

# Output: app-release-bundle.aab
```

---

## Langkah 3: Daftar Play Console

1. Buka **https://play.google.com/console**
2. Klik **Create developer account**
3. Bayar **$25** (one-time, seumur hidup)
4. Verifikasi identitas (KTP/SIM + selfie, butuh 1-3 hari)

---

## Langkah 4: Upload ke Play Store

1. Login ke **Play Console**
2. Klik **Create app**
   - App name: `Kas Vilkar Kosambi Blok D`
   - Default language: Indonesian
   - App type: Application
   - Free/Paid: Free
3. Buka app → **Production** → **Create release**
4. Upload **`.aab` file** dari Langkah 2
5. Isi **Release notes** (bahasa Indonesia): "Versi pertama - Vilkar Kosambi Blok D"
6. Klik **Next** → **Review release** → **Start rollout**

---

## Langkah 5: Isi Store Listing

Di Play Console, isi wajib:

### Main Store Listing
- **App name**: Kas Vilkar Kosambi Blok D
- **Short description**: Aplikasi pengelolaan kas, data warga, & dokumentasi Vilkar Kosambi Blok D
- **Full description**:
```
Vilkar Kosambi Blok D adalah aplikasi lengkap untuk pengelolaan:
- Kas Vilkar (uang masuk & keluar) dengan export laporan CSV
- Data warga lengkap (CRUD)
- Tagihan iuran warga per bulan
- Peminjaman uang warga + pembayaran
- Upload & download berkas warga
- Dokumentasi (planning & hasil tercapai)
- Dashboard dengan grafik keuangan

Fitur:
- Login Admin & Superadmin (role-based access)
- PWA - bisa diinstall di HP
- Mode offline-ready
- Export laporan kas ke CSV

Dibangun dengan Next.js + Prisma + SQLite.
```

### Graphics (wajib)
- **App icon**: 512x512 px (sudah ada: `public/icon-512.png`)
- **Feature graphic**: 1024x500 px (buat banner)
- **Phone screenshots**: minimum 2, ukuran 16:9 atau 9:16

### Categorization
- **App category**: Finance
- **Tags**: finance, management, community

### Privacy Policy
- Buat halaman privacy policy (bisa pakai generator: https://app-privacy-policy-generator.firebaseapp.com)
- Host di URL publik (mis: `https://kas-vilkar.vercel.app/privacy`)
- Isi URL di Play Console

### Content Rating
- Isi questionnaire (pilih "No" untuk semua pertanyaan violence/gambling dll)
- Rating: **Everyone**

### Target Audience
- Target age: 18+
- Target country: Indonesia

---

## Langkah 6: Tunggu Review

- Google review: **1-7 hari** (biasanya 2-3 hari)
- Kalau ditolak, perbaiki sesuai feedback Google
- Kalau diterima → app langsung muncul di Play Store!

---

## Checklist Sebelum Upload

- [ ] Aplikasi sudah deploy ke HTTPS
- [ ] manifest.json valid (cek: https://www.pwabuilder.com)
- [ ] Icon 512x512 ada
- [ ] Service worker jalan (test offline)
- [ ] Test di Android Chrome → menu → "Install app" berhasil
- [ ] Akun Play Console aktif ($25)
- [ ] .aab file sudah di-generate
- [ ] Keystore (.jks) disimpan aman (JANGAN hilangkan, kalau hilang tidak bisa update app!)
- [ ] Privacy policy URL siap
- [ ] Screenshots app siap (min 2)

---

## Tips Penting

### 1. Simpan Keystore dengan AMAN
File `.jks` (keystore) adalah identitas app Anda. Kalau hilang:
- Tidak bisa update app di Play Store
- Harus publish app baru dengan package ID berbeda
- **Backup ke multiple tempat**: Google Drive, email, flashdisk

### 2. Update App
Untuk update app di Play Store:
1. Edit code → deploy ulang ke hosting
2. Buka project Bubblewrap → `bubblewrap build` (versi naik)
3. Upload `.aab` baru ke Play Console → Production → Create release

### 3. Asset Links (Digital Asset Links)
PWABuilder/Bubblewrap otomatis generate `assetlinks.json`. Pastikan file ini accessible di:
```
https://kas-vilkar.vercel.app/.well-known/assetlinks.json
```
Kalau tidak ada, TWA akan show browser URL bar (tidak full-screen native).

### 4. Test Sebelum Publish
- Install `.apk` (debug build) di HP Android sendiri
- Test semua fitur jalan
- Baru upload `.aab` ke Play Store

---

## Estimasi Biaya & Waktu

| Item | Biaya | Waktu |
|------|-------|-------|
| Hosting (Vercel free) | $0 | 30 menit |
| Play Console account | $25 (one-time) | - |
| Generate .aab | $0 | 30 menit |
| Verifikasi identitas Google | $0 | 1-3 hari |
| Review Play Store | $0 | 1-7 hari |
| **Total** | **$25** | **3-10 hari** |

---

## Bantuan

Kalau bingung, tanya saya. Saya bisa bantu:
- Optimasi PWA config untuk lulus PWABuilder score
- Buat privacy policy page
- Setup deployment config
- Generate feature graphic & screenshots
