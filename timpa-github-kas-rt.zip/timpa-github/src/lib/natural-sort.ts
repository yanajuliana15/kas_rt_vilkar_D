// Urutan alami untuk NIK / kode rumah: D1-01 < D1-02 < D2-01 < D10-04 < D11-30
// (pengurutan string biasa salah: "D10-04" akan tampil sebelum "D2-01")
export function naturalCompare(a: string, b: string): number {
  const pa = a.toLowerCase().match(/\d+|\D+/g) ?? [];
  const pb = b.toLowerCase().match(/\d+|\D+/g) ?? [];
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const x = pa[i];
    const y = pb[i];
    if (x === undefined) return -1;
    if (y === undefined) return 1;
    const nx = /^\d+$/.test(x);
    const ny = /^\d+$/.test(y);
    if (nx && ny) {
      const d = parseInt(x, 10) - parseInt(y, 10);
      if (d !== 0) return d;
    } else if (x !== y) {
      return x < y ? -1 : 1;
    }
  }
  return 0;
}

// Urutkan daftar warga sesuai NIK (kode rumah), nama sebagai penentu bila seri
export function sortByNik<T extends { nik: string; namaLengkap?: string | null }>(
  list: T[]
): T[] {
  return [...list].sort(
    (a, b) =>
      naturalCompare(a.nik, b.nik) ||
      (a.namaLengkap ?? "").localeCompare(b.namaLengkap ?? "", "id")
  );
}
